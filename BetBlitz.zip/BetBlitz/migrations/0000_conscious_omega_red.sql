CREATE TABLE "bets" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"game_id" varchar NOT NULL,
	"bet_type" text NOT NULL,
	"amount" numeric(10, 2) NOT NULL,
	"odds" numeric(4, 2) NOT NULL,
	"potential_win" numeric(10, 2) NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"placed_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "games" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"home_team" text NOT NULL,
	"away_team" text NOT NULL,
	"home_team_color" text DEFAULT 'from-red-500 to-blue-600' NOT NULL,
	"away_team_color" text DEFAULT 'from-green-500 to-blue-500' NOT NULL,
	"venue" text NOT NULL,
	"game_date" timestamp NOT NULL,
	"status" text DEFAULT 'upcoming' NOT NULL,
	"home_odds" numeric(4, 2) NOT NULL,
	"away_odds" numeric(4, 2) NOT NULL,
	"draw_odds" numeric(4, 2) NOT NULL,
	"result" text,
	"home_score" integer DEFAULT 0,
	"away_score" integer DEFAULT 0
);
--> statement-breakpoint
CREATE TABLE "goal_predictions" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" varchar NOT NULL,
	"game_id" varchar NOT NULL,
	"player_name" text NOT NULL,
	"team" text NOT NULL,
	"predicted_goals" integer DEFAULT 1 NOT NULL,
	"actual_goals" integer,
	"status" text DEFAULT 'pending' NOT NULL,
	"reviewed_by" varchar,
	"reviewed_at" timestamp,
	"placed_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "sessions" (
	"sid" varchar PRIMARY KEY NOT NULL,
	"sess" text NOT NULL,
	"expire" timestamp NOT NULL
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"username" text NOT NULL,
	"balance" numeric(10, 2) DEFAULT '500.00' NOT NULL,
	"total_winnings" numeric(10, 2) DEFAULT '0.00' NOT NULL,
	"bets_won" integer DEFAULT 0 NOT NULL,
	"is_staff" boolean DEFAULT false NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "users_username_unique" UNIQUE("username")
);
--> statement-breakpoint
ALTER TABLE "bets" ADD CONSTRAINT "bets_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bets" ADD CONSTRAINT "bets_game_id_games_id_fk" FOREIGN KEY ("game_id") REFERENCES "public"."games"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "goal_predictions" ADD CONSTRAINT "goal_predictions_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "goal_predictions" ADD CONSTRAINT "goal_predictions_game_id_games_id_fk" FOREIGN KEY ("game_id") REFERENCES "public"."games"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "goal_predictions" ADD CONSTRAINT "goal_predictions_reviewed_by_users_id_fk" FOREIGN KEY ("reviewed_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;