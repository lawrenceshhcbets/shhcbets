import { sql } from "drizzle-orm";
import { pgTable, text, varchar, decimal, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table
export const sessions = pgTable("sessions", {
  sid: varchar("sid").primaryKey(),
  sess: text("sess").notNull(),
  expire: timestamp("expire").notNull(),
});

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password"), // For staff login
  balance: decimal("balance", { precision: 10, scale: 2 }).notNull().default("500.00"),
  totalWinnings: decimal("total_winnings", { precision: 10, scale: 2 }).notNull().default("0.00"),
  betsWon: integer("bets_won").notNull().default(0),
  isStaff: boolean("is_staff").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const games = pgTable("games", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  homeTeam: text("home_team").notNull(),
  awayTeam: text("away_team").notNull(),
  homeTeamColor: text("home_team_color").notNull().default("from-red-500 to-blue-600"),
  awayTeamColor: text("away_team_color").notNull().default("from-green-500 to-blue-500"),
  venue: text("venue").notNull(),
  gameDate: timestamp("game_date").notNull(),
  status: text("status").notNull().default("upcoming"), // upcoming, live, completed
  homeOdds: decimal("home_odds", { precision: 4, scale: 2 }).notNull(),
  awayOdds: decimal("away_odds", { precision: 4, scale: 2 }).notNull(),
  drawOdds: decimal("draw_odds", { precision: 4, scale: 2 }).notNull(),
  result: text("result"), // home, away, draw
  homeScore: integer("home_score").default(0),
  awayScore: integer("away_score").default(0),
});

// New table for player goal predictions
export const goalPredictions = pgTable("goal_predictions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  gameId: varchar("game_id").notNull().references(() => games.id),
  playerName: text("player_name").notNull(),
  team: text("team").notNull(), // home or away
  predictedGoals: integer("predicted_goals").notNull().default(1),
  actualGoals: integer("actual_goals"),
  status: text("status").notNull().default("pending"), // pending, approved, rejected, won, lost
  reviewedBy: varchar("reviewed_by").references(() => users.id),
  reviewedAt: timestamp("reviewed_at"),
  placedAt: timestamp("placed_at").notNull().defaultNow(),
});

export const bets = pgTable("bets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  gameId: varchar("game_id").notNull().references(() => games.id),
  betType: text("bet_type").notNull(), // home, away, draw
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  odds: decimal("odds", { precision: 4, scale: 2 }).notNull(),
  potentialWin: decimal("potential_win", { precision: 10, scale: 2 }).notNull(),
  status: text("status").notNull().default("pending"), // pending, won, lost
  placedAt: timestamp("placed_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
}).partial({
  password: true,
});

export const insertGameSchema = createInsertSchema(games).omit({
  id: true,
});

export const insertBetSchema = createInsertSchema(bets).omit({
  id: true,
  placedAt: true,
});

export const insertGoalPredictionSchema = createInsertSchema(goalPredictions).omit({
  id: true,
  placedAt: true,
  reviewedAt: true,
  reviewedBy: true,
  actualGoals: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertGame = z.infer<typeof insertGameSchema>;
export type Game = typeof games.$inferSelect;

export type InsertBet = z.infer<typeof insertBetSchema>;
export type Bet = typeof bets.$inferSelect;

export type InsertGoalPrediction = z.infer<typeof insertGoalPredictionSchema>;
export type GoalPrediction = typeof goalPredictions.$inferSelect;

export type BetWithGame = Bet & {
  game: Game;
};

export type GoalPredictionWithGame = GoalPrediction & {
  game: Game;
  user: User;
};

export type UserWithStats = User & {
  rank?: number;
};
