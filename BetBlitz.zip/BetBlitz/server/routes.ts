import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertBetSchema, insertGoalPredictionSchema, insertGameSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get or create user
  app.get("/api/user", async (req, res) => {
    try {
      const username = req.query.username as string;
      
      if (!username || username.trim().length < 3) {
        return res.status(400).json({ message: "Username must be at least 3 characters" });
      }

      // Block bot-like usernames
      const botPatterns = /bot|test|demo|fake|auto|script|robot/i;
      if (botPatterns.test(username)) {
        return res.status(400).json({ message: "Invalid username" });
      }
      
      let user = await storage.getUserByUsername(username.trim());
      if (!user) {
        user = await storage.createUser({ username: username.trim() });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to get user" });
    }
  });

  // Staff authentication routes
  app.post("/api/staff/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      const staff = await storage.authenticateStaff(username, password);
      
      if (staff) {
        res.json({ success: true, staff });
      } else {
        res.status(401).json({ success: false, message: "Invalid credentials" });
      }
    } catch (error) {
      console.error("Error authenticating staff:", error);
      res.status(500).json({ message: "Authentication failed" });
    }
  });

  // Get all games
  app.get("/api/games", async (req, res) => {
    try {
      const games = await storage.getAllGames();
      res.json(games);
    } catch (error) {
      res.status(500).json({ message: "Failed to get games" });
    }
  });

  // Place a bet
  app.post("/api/bets", async (req, res) => {
    try {
      const betData = insertBetSchema.parse(req.body);
      
      // Get user and check balance
      const user = await storage.getUser(betData.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const currentBalance = parseFloat(user.balance);
      const betAmount = parseFloat(betData.amount);

      if (currentBalance < betAmount) {
        return res.status(400).json({ message: "Insufficient balance" });
      }

      if (betAmount < 1 || betAmount > 1000) {
        return res.status(400).json({ message: "Bet amount must be between $1.00 and $1,000.00" });
      }

      // Calculate potential win
      const odds = parseFloat(betData.odds);
      const potentialWin = (betAmount * odds).toFixed(2);

      // Create bet with calculated potential win
      const bet = await storage.createBet({
        ...betData,
        potentialWin,
      });

      // Update user balance
      const newBalance = (currentBalance - betAmount).toFixed(2);
      await storage.updateUserBalance(betData.userId, newBalance);

      res.json(bet);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid bet data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to place bet" });
    }
  });

  // Get user bets
  app.get("/api/users/:userId/bets", async (req, res) => {
    try {
      const { userId } = req.params;
      const bets = await storage.getUserBets(userId);
      res.json(bets);
    } catch (error) {
      res.status(500).json({ message: "Failed to get user bets" });
    }
  });

  // Get leaderboard
  app.get("/api/leaderboard", async (req, res) => {
    try {
      const leaderboard = await storage.getLeaderboard();
      res.json(leaderboard);
    } catch (error) {
      res.status(500).json({ message: "Failed to get leaderboard" });
    }
  });

  // Create goal prediction
  app.post("/api/goal-predictions", async (req, res) => {
    try {
      const predictionData = insertGoalPredictionSchema.parse(req.body);
      
      const prediction = await storage.createGoalPrediction(predictionData);
      res.json(prediction);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid prediction data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create goal prediction" });
    }
  });

  // Get user's goal predictions
  app.get("/api/users/:userId/goal-predictions", async (req, res) => {
    try {
      const { userId } = req.params;
      const predictions = await storage.getUserGoalPredictions(userId);
      res.json(predictions);
    } catch (error) {
      res.status(500).json({ message: "Failed to get goal predictions" });
    }
  });

  // Staff routes - Get pending goal predictions for approval
  app.get("/api/staff/goal-predictions/pending", async (req, res) => {
    try {
      const predictions = await storage.getPendingGoalPredictions();
      res.json(predictions);
    } catch (error) {
      res.status(500).json({ message: "Failed to get pending predictions" });
    }
  });

  // Staff routes - Approve goal prediction
  app.post("/api/staff/goal-predictions/:predictionId/approve", async (req, res) => {
    try {
      const { predictionId } = req.params;
      const { reviewerId } = req.body;
      
      const prediction = await storage.approveGoalPrediction(predictionId, reviewerId);
      if (!prediction) {
        return res.status(404).json({ message: "Prediction not found" });
      }
      
      res.json(prediction);
    } catch (error) {
      res.status(500).json({ message: "Failed to approve prediction" });
    }
  });

  // Staff routes - Reject goal prediction
  app.post("/api/staff/goal-predictions/:predictionId/reject", async (req, res) => {
    try {
      const { predictionId } = req.params;
      const { reviewerId } = req.body;
      
      const prediction = await storage.rejectGoalPrediction(predictionId, reviewerId);
      if (!prediction) {
        return res.status(404).json({ message: "Prediction not found" });
      }
      
      res.json(prediction);
    } catch (error) {
      res.status(500).json({ message: "Failed to reject prediction" });
    }
  });

  // Staff routes - Create new game
  app.post("/api/staff/games", async (req, res) => {
    try {
      const gameData = insertGameSchema.parse(req.body);
      const game = await storage.createGame(gameData);
      res.json(game);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid game data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create game" });
    }
  });

  // Update user balance (for testing/admin)
  app.patch("/api/users/:userId/balance", async (req, res) => {
    try {
      const { userId } = req.params;
      const { balance } = req.body;
      
      const user = await storage.updateUserBalance(userId, balance.toString());
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to update balance" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
