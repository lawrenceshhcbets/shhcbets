import { 
  type User, 
  type InsertUser, 
  type Game, 
  type InsertGame, 
  type Bet, 
  type InsertBet, 
  type BetWithGame, 
  type UserWithStats,
  type GoalPrediction,
  type InsertGoalPrediction,
  type GoalPredictionWithGame,
  users,
  games,
  bets,
  goalPredictions
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  authenticateStaff(username: string, password: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserBalance(userId: string, newBalance: string): Promise<User | undefined>;
  updateUserStats(userId: string, winnings: string, betsWon: number): Promise<User | undefined>;
  getLeaderboard(): Promise<UserWithStats[]>;

  // Game operations
  getAllGames(): Promise<Game[]>;
  createGame(game: InsertGame): Promise<Game>;
  getGame(id: string): Promise<Game | undefined>;
  createGame(game: InsertGame): Promise<Game>;
  updateGameResult(gameId: string, result: string): Promise<Game | undefined>;

  // Bet operations
  getUserBets(userId: string): Promise<BetWithGame[]>;
  createBet(bet: InsertBet): Promise<Bet>;
  getBetsByGame(gameId: string): Promise<Bet[]>;
  updateBetStatus(betId: string, status: string): Promise<Bet | undefined>;

  // Goal prediction operations
  createGoalPrediction(prediction: InsertGoalPrediction): Promise<GoalPrediction>;
  getUserGoalPredictions(userId: string): Promise<GoalPredictionWithGame[]>;
  getPendingGoalPredictions(): Promise<GoalPredictionWithGame[]>;
  approveGoalPrediction(predictionId: string, reviewerId: string): Promise<GoalPrediction | undefined>;
  rejectGoalPrediction(predictionId: string, reviewerId: string): Promise<GoalPrediction | undefined>;
  updateGoalPredictionResult(predictionId: string, actualGoals: number): Promise<GoalPrediction | undefined>;
}

export class DatabaseStorage implements IStorage {
  async initializeData() {
    // Create staff user if it doesn't exist
    const existingStaff = await db.select().from(users).where(eq(users.isStaff, true)).limit(1);
    if (existingStaff.length === 0) {
      await db.insert(users).values([
        { username: "STAFF", password: "292992", balance: "0.00", totalWinnings: "0.00", betsWon: 0, isStaff: true }
      ]);
    }

    // Remove any bot-like users
    const botPatterns = /bot|test|demo|fake|auto|script|robot|user\d+/i;
    const allUsers = await db.select().from(users).where(eq(users.isStaff, false));
    
    for (const user of allUsers) {
      if (botPatterns.test(user.username)) {
        // Delete their bets first
        await db.delete(bets).where(eq(bets.userId, user.id));
        // Delete their goal predictions
        await db.delete(goalPredictions).where(eq(goalPredictions.userId, user.id));
        // Delete the user
        await db.delete(users).where(eq(users.id, user.id));
      }
    }
  }

  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async authenticateStaff(username: string, password: string): Promise<User | undefined> {
    const [user] = await db.select().from(users)
      .where(eq(users.username, username));
    
    if (user && user.isStaff && user.password === password) {
      return user;
    }
    return undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        username: insertUser.username,
        balance: "500.00",
        totalWinnings: "0.00",
        betsWon: 0,
        isStaff: false,
      })
      .returning();
    return user;
  }

  async updateUserBalance(userId: string, newBalance: string): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ balance: newBalance })
      .where(eq(users.id, userId))
      .returning();
    return user || undefined;
  }

  async updateUserStats(userId: string, winnings: string, betsWon: number): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ totalWinnings: winnings, betsWon })
      .where(eq(users.id, userId))
      .returning();
    return user || undefined;
  }

  async getLeaderboard(): Promise<UserWithStats[]> {
    const allUsers = await db.select().from(users)
      .where(eq(users.isStaff, false))
      .orderBy(desc(users.balance));
    return allUsers.map((user, index) => ({ ...user, rank: index + 1 }));
  }

  async getAllGames(): Promise<Game[]> {
    return await db.select().from(games).orderBy(games.gameDate);
  }

  async createGame(game: InsertGame): Promise<Game> {
    const [newGame] = await db.insert(games).values(game).returning();
    return newGame;
  }

  async getGame(id: string): Promise<Game | undefined> {
    const [game] = await db.select().from(games).where(eq(games.id, id));
    return game || undefined;
  }

  async createGame(insertGame: InsertGame): Promise<Game> {
    const [game] = await db
      .insert(games)
      .values(insertGame)
      .returning();
    return game;
  }

  async updateGameResult(gameId: string, result: string): Promise<Game | undefined> {
    const [game] = await db
      .update(games)
      .set({ result, status: "completed" })
      .where(eq(games.id, gameId))
      .returning();
    return game || undefined;
  }

  async getUserBets(userId: string): Promise<BetWithGame[]> {
    const userBets = await db
      .select({
        bet: bets,
        game: games,
      })
      .from(bets)
      .leftJoin(games, eq(bets.gameId, games.id))
      .where(eq(bets.userId, userId))
      .orderBy(desc(bets.placedAt));

    return userBets.map(row => ({ ...row.bet, game: row.game! }));
  }

  async createBet(insertBet: InsertBet): Promise<Bet> {
    const [bet] = await db
      .insert(bets)
      .values(insertBet)
      .returning();
    return bet;
  }

  async getBetsByGame(gameId: string): Promise<Bet[]> {
    return await db.select().from(bets).where(eq(bets.gameId, gameId));
  }

  async updateBetStatus(betId: string, status: string): Promise<Bet | undefined> {
    const [bet] = await db
      .update(bets)
      .set({ status })
      .where(eq(bets.id, betId))
      .returning();
    return bet || undefined;
  }

  // Goal prediction operations
  async createGoalPrediction(prediction: InsertGoalPrediction): Promise<GoalPrediction> {
    const [goalPrediction] = await db
      .insert(goalPredictions)
      .values(prediction)
      .returning();
    return goalPrediction;
  }

  async getUserGoalPredictions(userId: string): Promise<GoalPredictionWithGame[]> {
    const userPredictions = await db
      .select({
        prediction: goalPredictions,
        game: games,
        user: users,
      })
      .from(goalPredictions)
      .leftJoin(games, eq(goalPredictions.gameId, games.id))
      .leftJoin(users, eq(goalPredictions.userId, users.id))
      .where(eq(goalPredictions.userId, userId))
      .orderBy(desc(goalPredictions.placedAt));

    return userPredictions.map(row => ({ 
      ...row.prediction, 
      game: row.game!, 
      user: row.user! 
    }));
  }

  async getPendingGoalPredictions(): Promise<GoalPredictionWithGame[]> {
    const pendingPredictions = await db
      .select({
        prediction: goalPredictions,
        game: games,
        user: users,
      })
      .from(goalPredictions)
      .leftJoin(games, eq(goalPredictions.gameId, games.id))
      .leftJoin(users, eq(goalPredictions.userId, users.id))
      .where(eq(goalPredictions.status, "pending"))
      .orderBy(desc(goalPredictions.placedAt));

    return pendingPredictions.map(row => ({ 
      ...row.prediction, 
      game: row.game!, 
      user: row.user! 
    }));
  }

  async approveGoalPrediction(predictionId: string, reviewerId: string): Promise<GoalPrediction | undefined> {
    const [prediction] = await db
      .update(goalPredictions)
      .set({ 
        status: "approved", 
        reviewedBy: reviewerId, 
        reviewedAt: new Date() 
      })
      .where(eq(goalPredictions.id, predictionId))
      .returning();
    return prediction || undefined;
  }

  async rejectGoalPrediction(predictionId: string, reviewerId: string): Promise<GoalPrediction | undefined> {
    const [prediction] = await db
      .update(goalPredictions)
      .set({ 
        status: "rejected", 
        reviewedBy: reviewerId, 
        reviewedAt: new Date() 
      })
      .where(eq(goalPredictions.id, predictionId))
      .returning();
    return prediction || undefined;
  }

  async updateGoalPredictionResult(predictionId: string, actualGoals: number): Promise<GoalPrediction | undefined> {
    const [prediction] = await db
      .update(goalPredictions)
      .set({ actualGoals })
      .where(eq(goalPredictions.id, predictionId))
      .returning();
    return prediction || undefined;
  }
}

export const storage = new DatabaseStorage();

// Initialize data on startup
storage.initializeData().catch(console.error);
