import { useQuery } from "@tanstack/react-query";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { UserWithStats } from "@shared/schema";

export default function Leaderboard() {
  const { data: rawLeaderboard = [] } = useQuery<UserWithStats[]>({
    queryKey: ["/api/leaderboard"],
  });

  // Filter out staff users and ensure proper ranking
  const leaderboard = rawLeaderboard
    .filter(user => !user.isStaff)
    .map((user, index) => ({ ...user, rank: index + 1 }));

  const getRankColor = (rank: number) => {
    switch (rank) {
      case 1:
        return "bg-shhc-yellow text-black";
      case 2:
        return "bg-gray-600 text-white";
      case 3:
        return "bg-orange-600 text-white";
      default:
        return "bg-gray-700 text-white";
    }
  };

  const getCardBackground = (rank: number) => {
    switch (rank) {
      case 1:
        return "bg-gradient-to-r from-shhc-yellow/20 to-shhc-green/20 border border-shhc-yellow/30";
      default:
        return "bg-gray-700/50";
    }
  };

  const getBalanceChange = (user: UserWithStats) => {
    const balance = parseFloat(user.balance);
    const totalWinnings = parseFloat(user.totalWinnings);
    const change = totalWinnings;
    
    if (change > 0) {
      return `+$${change.toFixed(2)}`;
    } else if (change < 0) {
      return `-$${Math.abs(change).toFixed(2)}`;
    }
    return "$0.00";
  };

  const getChangeColor = (user: UserWithStats) => {
    const change = parseFloat(user.totalWinnings);
    if (change > 0) return "text-shhc-green";
    if (change < 0) return "text-shhc-red";
    return "text-gray-400";
  };

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold">
          <i className="fas fa-trophy text-shhc-yellow mr-2"></i>
          Leaderboard
        </h3>
        <Select defaultValue="week">
          <SelectTrigger className="w-[120px] bg-gray-700 border-gray-600 text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="week">This Week</SelectItem>
            <SelectItem value="month">This Month</SelectItem>
            <SelectItem value="alltime">All Time</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div className="space-y-3">
        {leaderboard.length === 0 ? (
          <div className="text-center py-8 text-gray-400">
            <i className="fas fa-trophy text-2xl mb-2 block"></i>
            <p>No players yet</p>
            <p className="text-xs">Create an account to start betting and appear on the leaderboard</p>
          </div>
        ) : (
          leaderboard.map((user) => (
            <div key={user.id} className={`flex items-center space-x-3 p-3 rounded-lg ${getCardBackground(user.rank || 0)}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${getRankColor(user.rank || 0)}`}>
                {user.rank}
              </div>
              <div className="flex-1">
                <div className="font-medium">{user.username}</div>
                <div className="text-xs text-gray-400">{user.betsWon} bets won</div>
              </div>
              <div className="text-right">
                <div className="font-bold text-shhc-green">${parseFloat(user.balance).toFixed(2)}</div>
                <div className={`text-xs ${getChangeColor(user)}`}>
                  {getBalanceChange(user)}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
