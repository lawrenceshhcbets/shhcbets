import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface StaffLoginProps {
  onLogin: (staff: any) => void;
}

export default function StaffLogin({ onLogin }: StaffLoginProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const response = await apiRequest("POST", "/api/staff/login", {
        username,
        password,
      });
      const data = await response.json();

      if (data.success) {
        toast({
          title: "Welcome back!",
          description: "Successfully logged in as staff member.",
        });
        onLogin(data.staff);
      } else {
        toast({
          title: "Login failed",
          description: "Invalid username or password.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Login error",
        description: "Unable to connect to authentication server.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-shhc-bg flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-shhc-secondary border-gray-700">
        <CardHeader className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-shhc-green to-shhc-blue rounded-full flex items-center justify-center">
            <i className="fas fa-shield-alt text-2xl text-white"></i>
          </div>
          <CardTitle className="text-2xl font-bold text-white">
            SHHC Sports Management
          </CardTitle>
          <p className="text-gray-400">Authorized Personnel Only</p>
          <div className="text-xs text-gray-500 mt-2">
            Secure Staff Access Portal
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="text-sm text-gray-400 mb-2 block">Username</label>
              <Input
                type="text"
                placeholder="Enter staff username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="bg-gray-700 border-gray-600 focus:border-shhc-blue"
                required
              />
            </div>
            <div>
              <label className="text-sm text-gray-400 mb-2 block">Password</label>
              <Input
                type="password"
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-gray-700 border-gray-600 focus:border-shhc-blue"
                required
              />
            </div>
            <Button
              type="submit"
              className="w-full bg-shhc-blue hover:bg-shhc-blue/80 text-white font-semibold py-3"
              disabled={isLoading}
            >
              {isLoading ? "Logging in..." : "Login"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}