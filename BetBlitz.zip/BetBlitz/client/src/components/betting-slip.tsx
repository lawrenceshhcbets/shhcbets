import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { X } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { User } from "@shared/schema";

interface BettingSlipProps {
  selectedBets: Array<{
    gameId: string;
    betType: string;
    odds: string;
    gameTitle: string;
  }>;
  onRemoveBet: (gameId: string) => void;
  onClearAll: () => void;
  user?: User;
}

export default function BettingSlip({ selectedBets, onRemoveBet, onClearAll, user }: BettingSlipProps) {
  const [betAmounts, setBetAmounts] = useState<Record<string, string>>({});
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const placeBetMutation = useMutation({
    mutationFn: async (betData: any) => {
      const response = await apiRequest("POST", "/api/bets", betData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Bet placed successfully!",
        description: "Your bet has been added to your betting history.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      onClearAll();
      setBetAmounts({});
    },
    onError: (error: any) => {
      toast({
        title: "Failed to place bet",
        description: error.message || "Something went wrong",
        variant: "destructive",
      });
    },
  });

  const handleAmountChange = (gameId: string, amount: string) => {
    setBetAmounts(prev => ({ ...prev, [gameId]: amount }));
  };

  const calculatePotentialWin = (odds: string, amount: string) => {
    const oddsNum = parseFloat(odds);
    const amountNum = parseFloat(amount) || 0;
    return (oddsNum * amountNum).toFixed(2);
  };

  const getTotalBetAmount = () => {
    return selectedBets.reduce((total, bet) => {
      const amount = parseFloat(betAmounts[bet.gameId]) || 0;
      return total + amount;
    }, 0);
  };

  const handlePlaceBets = async () => {
    if (!user) return;

    const betsToPlace = selectedBets
      .filter(bet => betAmounts[bet.gameId] && parseFloat(betAmounts[bet.gameId]) > 0)
      .map(bet => ({
        userId: user.id,
        gameId: bet.gameId,
        betType: bet.betType,
        amount: betAmounts[bet.gameId],
        odds: bet.odds,
      }));

    if (betsToPlace.length === 0) {
      toast({
        title: "No valid bets",
        description: "Please enter bet amounts for your selected bets.",
        variant: "destructive",
      });
      return;
    }

    // For simplicity, place one bet at a time
    for (const bet of betsToPlace) {
      await placeBetMutation.mutateAsync(bet);
    }
  };

  const getBetTypeName = (betType: string, gameTitle: string) => {
    const [homeTeam, awayTeam] = gameTitle.split(' vs ');
    switch (betType) {
      case 'home':
        return `${homeTeam} Win`;
      case 'away':
        return `${awayTeam} Win`;
      case 'draw':
        return 'Draw';
      default:
        return betType;
    }
  };

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold">Betting Slip</h3>
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={onClearAll}
          className="text-sm text-gray-400 hover:text-white"
        >
          Clear All
        </Button>
      </div>
      
      <div className="space-y-3">
        {selectedBets.length === 0 ? (
          <div className="text-center py-8 text-gray-400">
            <i className="fas fa-receipt text-3xl mb-3 opacity-50"></i>
            <p>Your betting slip is empty</p>
            <p className="text-sm">Click on odds to add bets</p>
          </div>
        ) : (
          selectedBets.map((bet) => (
            <div key={bet.gameId} className="bg-gray-700 rounded-lg p-4 border-l-4 border-shhc-green">
              <div className="flex justify-between items-start mb-2">
                <div className="text-sm font-medium">
                  {getBetTypeName(bet.betType, bet.gameTitle)}
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onRemoveBet(bet.gameId)}
                  className="text-gray-400 hover:text-white p-0 h-auto"
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
              <div className="text-xs text-gray-400 mb-3">{bet.gameTitle}</div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm">Odds:</span>
                <span className="font-bold text-shhc-yellow">{bet.odds}</span>
              </div>
              <div className="space-y-2">
                <Input
                  type="number"
                  placeholder="Bet amount ($)"
                  value={betAmounts[bet.gameId] || ""}
                  onChange={(e) => handleAmountChange(bet.gameId, e.target.value)}
                  className="w-full bg-gray-800 border border-gray-600 focus:border-shhc-green"
                  min="1"
                  max="1000"
                />
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Potential Win:</span>
                  <span className="font-medium text-shhc-green">
                    ${calculatePotentialWin(bet.odds, betAmounts[bet.gameId] || "0")}
                  </span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
      
      {selectedBets.length > 0 && (
        <>
          <Button 
            className="w-full bg-shhc-green hover:bg-shhc-green/80 text-white font-semibold py-3 rounded-lg mt-4 transition-colors"
            onClick={handlePlaceBets}
            disabled={placeBetMutation.isPending || getTotalBetAmount() === 0}
          >
            <i className="fas fa-check mr-2"></i>
            {placeBetMutation.isPending ? "Placing Bets..." : `Place Bet ($${getTotalBetAmount().toFixed(2)})`}
          </Button>
          
          <div className="text-xs text-gray-400 mt-2 text-center">
            Min bet: $1.00 | Max bet: $1,000.00
          </div>
        </>
      )}
    </div>
  );
}
