import { Game } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";

interface GameCardProps {
  game: Game;
  onAddBet: (gameId: string, betType: string, odds: string, gameTitle: string) => void;
  selectedBet?: {
    gameId: string;
    betType: string;
    odds: string;
    gameTitle: string;
  };
}

export default function GameCard({ game, onAddBet, selectedBet }: GameCardProps) {
  const isLive = game.status === "live";
  const gameTitle = `${game.homeTeam} vs ${game.awayTeam}`;
  
  const formatGameTime = (date: Date) => {
    if (isLive) return "LIVE NOW";
    
    const now = new Date();
    const gameDate = new Date(date);
    
    if (gameDate.toDateString() === now.toDateString()) {
      return `Today, ${gameDate.toLocaleTimeString('en-US', { 
        hour: 'numeric', 
        minute: '2-digit',
        hour12: true 
      })}`;
    }
    
    if (gameDate.toDateString() === new Date(now.getTime() + 24 * 60 * 60 * 1000).toDateString()) {
      return `Tomorrow, ${gameDate.toLocaleTimeString('en-US', { 
        hour: 'numeric', 
        minute: '2-digit',
        hour12: true 
      })}`;
    }
    
    return gameDate.toLocaleDateString('en-US', {
      weekday: 'long',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  const handleBetClick = (betType: string, odds: string) => {
    onAddBet(game.id, betType, odds, gameTitle);
  };

  const getBetButtonClass = (betType: string) => {
    const isSelected = selectedBet?.betType === betType;
    return `w-full transition-all duration-200 ${
      isSelected 
        ? 'bg-shhc-green bg-opacity-30 border-shhc-green text-white' 
        : 'bg-gray-700 hover:bg-shhc-green hover:bg-opacity-20 border-transparent hover:border-shhc-green'
    } border p-3 rounded-lg`;
  };

  return (
    <div className="bg-shhc-secondary rounded-xl p-6 border border-gray-700 hover:border-gray-600 transition-all duration-200">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className={`w-3 h-3 rounded-full ${isLive ? 'bg-shhc-green animate-pulse' : 'bg-gray-500'}`}></div>
          <span className={`text-sm font-medium ${isLive ? 'text-shhc-green' : 'text-gray-400'}`}>
            {isLive ? 'LIVE BETTING' : 'UPCOMING'}
          </span>
        </div>
        <div className="text-sm text-gray-400">{formatGameTime(game.gameDate)}</div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
        {/* Teams */}
        <div className="col-span-1 md:col-span-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="text-center">
                <div className={`w-12 h-12 bg-gradient-to-br ${game.homeTeamColor} rounded-lg flex items-center justify-center mb-2`}>
                  <i className="fas fa-hockey-puck text-white"></i>
                </div>
                <div className="font-semibold">{game.homeTeam}</div>
                <div className="text-sm text-gray-400">Home</div>
              </div>
            </div>
            
            <div className="text-center">
              <div className="text-2xl font-bold text-shhc-yellow">VS</div>
              <div className="text-sm text-gray-400">{game.venue}</div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="text-center">
                <div className={`w-12 h-12 bg-gradient-to-br ${game.awayTeamColor} rounded-lg flex items-center justify-center mb-2`}>
                  <i className="fas fa-hockey-puck text-white"></i>
                </div>
                <div className="font-semibold">{game.awayTeam}</div>
                <div className="text-sm text-gray-400">Away</div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Betting Options */}
        <div className="space-y-3">
          <Button 
            className={getBetButtonClass('home')}
            onClick={() => handleBetClick('home', game.homeOdds)}
          >
            <div className="flex justify-between items-center w-full">
              <span className="font-medium">{game.homeTeam} Win</span>
              <span className="text-shhc-yellow font-bold">{game.homeOdds}</span>
            </div>
          </Button>
          <Button 
            className={getBetButtonClass('away')}
            onClick={() => handleBetClick('away', game.awayOdds)}
          >
            <div className="flex justify-between items-center w-full">
              <span className="font-medium">{game.awayTeam} Win</span>
              <span className="text-shhc-yellow font-bold">{game.awayOdds}</span>
            </div>
          </Button>
          <Button 
            className={getBetButtonClass('draw')}
            onClick={() => handleBetClick('draw', game.drawOdds)}
          >
            <div className="flex justify-between items-center w-full">
              <span className="font-medium">Draw</span>
              <span className="text-shhc-yellow font-bold">{game.drawOdds}</span>
            </div>
          </Button>
        </div>
      </div>
    </div>
  );
}
