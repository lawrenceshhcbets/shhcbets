import { User } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { Link } from "wouter";
import shhcLogo from "@assets/image_1753419754593.png";

interface SidebarProps {
  user?: User;
}

export default function Sidebar({ user }: SidebarProps) {
  return (
    <aside className="lg:w-64 bg-shhc-secondary border-r border-gray-700">
      <div className="p-4">
        {/* Logo */}
        <div className="flex items-center space-x-3 mb-8">
          <div className="w-12 h-12 rounded-lg overflow-hidden bg-white/10 p-1">
            <img src={shhcLogo} alt="SHHCPL" className="w-full h-full object-contain" />
          </div>
          <div>
            <h1 className="text-xl font-bold">SHHC Sports</h1>
            <p className="text-sm text-gray-400">Gaming Platform</p>
          </div>
        </div>

        {/* User Balance */}
        <div className="bg-gradient-to-r from-shhc-green to-shhc-blue p-4 rounded-xl mb-6">
          <div className="text-sm text-gray-200">Your Balance</div>
          <div className="text-2xl font-bold">
            ${user?.balance ? parseFloat(user.balance).toFixed(2) : "500.00"}
          </div>
          <Button variant="ghost" size="sm" className="text-sm text-gray-200 hover:text-white mt-1 p-0 h-auto">
            <Plus className="mr-1 h-3 w-3" />
            Add Funds
          </Button>
        </div>

        {/* Navigation Menu */}
        <nav className="space-y-2">
          <a href="#" className="flex items-center space-x-3 p-3 rounded-lg bg-shhc-green bg-opacity-20 text-shhc-green">
            <i className="fas fa-home w-5"></i>
            <span>Dashboard</span>
          </a>
          <a href="#" className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-700 text-gray-300 hover:text-white transition-colors">
            <i className="fas fa-hockey-puck w-5"></i>
            <span>Games</span>
          </a>
          <a href="#" className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-700 text-gray-300 hover:text-white transition-colors">
            <i className="fas fa-receipt w-5"></i>
            <span>My Bets</span>
          </a>
          <a href="#" className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-700 text-gray-300 hover:text-white transition-colors">
            <i className="fas fa-trophy w-5"></i>
            <span>Leaderboard</span>
          </a>
          <a href="#" className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-700 text-gray-300 hover:text-white transition-colors">
            <i className="fas fa-history w-5"></i>
            <span>History</span>
          </a>
          <Link href="/staff" className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-700 text-gray-300 hover:text-yellow-400 transition-colors border-t border-gray-600 mt-2 pt-4">
            <i className="fas fa-shield-alt w-5"></i>
            <span>Staff Portal</span>
          </Link>
        </nav>
      </div>
    </aside>
  );
}