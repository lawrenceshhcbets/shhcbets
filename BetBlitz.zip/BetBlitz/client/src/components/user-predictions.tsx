import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { GoalPredictionWithGame, User } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

interface UserPredictionsProps {
  user?: User;
}

export default function UserPredictions({ user }: UserPredictionsProps) {
  const { data: predictions = [] } = useQuery<GoalPredictionWithGame[]>({
    queryKey: ["/api/users", user?.id, "goal-predictions"],
    enabled: !!user,
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved":
        return "bg-shhc-green text-white";
      case "rejected":
        return "bg-shhc-red text-white";
      case "won":
        return "bg-shhc-yellow text-black";
      case "lost":
        return "bg-gray-600 text-white";
      default:
        return "bg-shhc-blue text-white";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "approved":
        return "fas fa-check";
      case "rejected":
        return "fas fa-times";
      case "won":
        return "fas fa-trophy";
      case "lost":
        return "fas fa-times-circle";
      default:
        return "fas fa-clock";
    }
  };

  return (
    <div className="mb-8">
      <h3 className="text-lg font-semibold mb-4">
        <i className="fas fa-hockey-puck text-shhc-blue mr-2"></i>
        My Goal Predictions
      </h3>
      
      <div className="space-y-3">
        {predictions.length === 0 ? (
          <div className="text-center py-8 text-gray-400">
            <i className="fas fa-hockey-puck text-3xl mb-3 opacity-50"></i>
            <p>No goal predictions yet</p>
            <p className="text-sm">Submit your first prediction below!</p>
          </div>
        ) : (
          predictions.map((prediction) => (
            <div key={prediction.id} className="bg-gray-700/50 rounded-lg p-4 border-l-4 border-shhc-blue">
              <div className="flex justify-between items-start mb-2">
                <div className="text-sm font-medium">
                  {prediction.playerName} - {prediction.predictedGoals} Goal{prediction.predictedGoals > 1 ? 's' : ''}
                </div>
                <Badge className={getStatusColor(prediction.status)}>
                  <i className={`${getStatusIcon(prediction.status)} mr-1`}></i>
                  {prediction.status.charAt(0).toUpperCase() + prediction.status.slice(1)}
                </Badge>
              </div>
              
              <div className="text-xs text-gray-400 mb-2">
                {prediction.game.homeTeam} vs {prediction.game.awayTeam}
              </div>
              
              <div className="flex items-center justify-between">
                <div className="text-xs text-gray-400">
                  {formatDistanceToNow(prediction.placedAt)} ago
                </div>
                <div className="text-xs bg-gray-600 px-2 py-1 rounded">
                  {prediction.team === 'home' ? prediction.game.homeTeam : prediction.game.awayTeam}
                </div>
              </div>
              
              {prediction.status === "approved" && prediction.game.status === "completed" && prediction.actualGoals !== null && (
                <div className="mt-2 pt-2 border-t border-gray-600">
                  <div className="text-xs text-gray-300">
                    <strong>Actual Goals:</strong> {prediction.actualGoals}
                    {prediction.actualGoals === prediction.predictedGoals ? (
                      <span className="ml-2 text-shhc-green">✓ Correct!</span>
                    ) : (
                      <span className="ml-2 text-shhc-red">✗ Incorrect</span>
                    )}
                  </div>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}