import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Game, User } from "@shared/schema";

interface GoalPredictionCardProps {
  game: Game;
  user?: User;
}

export default function GoalPredictionCard({ game, user }: GoalPredictionCardProps) {
  const [playerName, setPlayerName] = useState("");
  const [team, setTeam] = useState<string>("");
  const [predictedGoals, setPredictedGoals] = useState("1");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createPredictionMutation = useMutation({
    mutationFn: async (predictionData: any) => {
      const response = await apiRequest("POST", "/api/goal-predictions", predictionData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Prediction submitted!",
        description: "Your goal prediction is waiting for staff approval.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/users", user?.id, "goal-predictions"] });
      // Reset form
      setPlayerName("");
      setTeam("");
      setPredictedGoals("1");
    },
    onError: (error: any) => {
      toast({
        title: "Failed to submit prediction",
        description: error.message || "Something went wrong",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = async () => {
    if (!user || !playerName.trim() || !team) {
      toast({
        title: "Missing information",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    await createPredictionMutation.mutateAsync({
      userId: user.id,
      gameId: game.id,
      playerName: playerName.trim(),
      team,
      predictedGoals: parseInt(predictedGoals),
    });
  };

  const isLive = game.status === "live";
  const isUpcoming = game.status === "upcoming";

  if (!isUpcoming && !isLive) {
    return null; // Don't show for completed games
  }

  return (
    <div className="bg-shhc-secondary rounded-xl p-6 border border-gray-700">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="w-3 h-3 rounded-full bg-shhc-blue animate-pulse"></div>
          <span className="text-sm font-medium text-shhc-blue">GOAL PREDICTION</span>
        </div>
        <div className="text-sm text-gray-400">
          {game.homeTeam} vs {game.awayTeam}
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <label className="text-sm text-gray-400 mb-2 block">Player Name</label>
          <Input
            type="text"
            placeholder="Enter player name..."
            value={playerName}
            onChange={(e) => setPlayerName(e.target.value)}
            className="bg-gray-700 border-gray-600 focus:border-shhc-blue"
          />
        </div>

        <div>
          <label className="text-sm text-gray-400 mb-2 block">Team</label>
          <Select value={team} onValueChange={setTeam}>
            <SelectTrigger className="bg-gray-700 border-gray-600">
              <SelectValue placeholder="Select team" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="home">{game.homeTeam}</SelectItem>
              <SelectItem value="away">{game.awayTeam}</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="text-sm text-gray-400 mb-2 block">Predicted Goals</label>
          <Select value={predictedGoals} onValueChange={setPredictedGoals}>
            <SelectTrigger className="bg-gray-700 border-gray-600">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1">1 Goal</SelectItem>
              <SelectItem value="2">2 Goals</SelectItem>
              <SelectItem value="3">3+ Goals</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Button 
          className="w-full bg-shhc-blue hover:bg-shhc-blue/80 text-white font-semibold py-3 rounded-lg transition-colors"
          onClick={handleSubmit}
          disabled={createPredictionMutation.isPending || !playerName.trim() || !team}
        >
          {createPredictionMutation.isPending ? (
            "Submitting..."
          ) : (
            <>
              <i className="fas fa-hockey-puck mr-2"></i>
              Submit Goal Prediction
            </>
          )}
        </Button>
        
        <div className="text-xs text-gray-400 text-center">
          Predictions require staff approval before they become active
        </div>
      </div>
    </div>
  );
}