export default function RecentActivity() {
  const activities: any[] = [];

  const getActivityColor = (type: string) => {
    switch (type) {
      case "win":
        return "bg-shhc-green";
      case "loss":
        return "bg-shhc-red";
      case "join":
        return "bg-shhc-blue";
      default:
        return "bg-gray-500";
    }
  };

  const getActivityText = (activity: any) => {
    switch (activity.type) {
      case "win":
        return `${activity.user} won $${activity.amount}`;
      case "loss":
        return `${activity.user} lost $${activity.amount}`;
      case "join":
        return `New user ${activity.user} joined`;
      default:
        return `${activity.user} activity`;
    }
  };

  return (
    <div>
      <h3 className="text-lg font-semibold mb-4">
        <i className="fas fa-clock text-shhc-blue mr-2"></i>
        Recent Activity
      </h3>
      
      <div className="space-y-3">
        {activities.length === 0 ? (
          <div className="text-center py-8 text-gray-400">
            <i className="fas fa-clock text-2xl mb-2 block"></i>
            <p>No recent activity</p>
            <p className="text-xs">Activity will appear here when users place bets</p>
          </div>
        ) : (
          activities.map((activity) => (
            <div key={activity.id} className="flex items-center space-x-3 p-3 bg-gray-700/30 rounded-lg">
              <div className={`w-2 h-2 rounded-full ${getActivityColor(activity.type)}`}></div>
              <div className="flex-1">
                <div className="text-sm">{getActivityText(activity)}</div>
                <div className="text-xs text-gray-400">{activity.game}</div>
              </div>
              <div className="text-xs text-gray-400">{activity.timeAgo}</div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
