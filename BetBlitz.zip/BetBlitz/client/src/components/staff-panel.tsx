import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Check, X, Clock, Plus, GamepadIcon } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { GoalPredictionWithGame, User, Game } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { useState } from "react";

interface StaffPanelProps {
  staffUser?: User;
  onLogout?: () => void;
}

export default function StaffPanel({ staffUser, onLogout }: StaffPanelProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Game creation form state
  const [gameForm, setGameForm] = useState({
    homeTeam: "",
    awayTeam: "",
    venue: "",
    gameDate: "",
    homeOdds: "2.50",
    awayOdds: "2.50",
    drawOdds: "3.20"
  });

  const { data: pendingPredictions = [] } = useQuery<GoalPredictionWithGame[]>({
    queryKey: ["/api/staff/goal-predictions/pending"],
    enabled: staffUser?.isStaff,
  });

  const { data: games = [] } = useQuery<Game[]>({
    queryKey: ["/api/games"],
    enabled: staffUser?.isStaff,
  });

  const createGameMutation = useMutation({
    mutationFn: async (gameData: any) => {
      const response = await apiRequest("POST", "/api/staff/games", gameData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Game created",
        description: "New game has been added to the schedule.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/games"] });
      setGameForm({
        homeTeam: "",
        awayTeam: "",
        venue: "",
        gameDate: "",
        homeOdds: "2.50",
        awayOdds: "2.50",
        drawOdds: "3.20"
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to create game",
        description: error.message || "Something went wrong",
        variant: "destructive",
      });
    },
  });

  const approveMutation = useMutation({
    mutationFn: async (predictionId: string) => {
      const response = await apiRequest("POST", `/api/staff/goal-predictions/${predictionId}/approve`, {
        reviewerId: staffUser?.id,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Prediction approved",
        description: "The goal prediction has been approved.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/staff/goal-predictions/pending"] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to approve",
        description: error.message || "Something went wrong",
        variant: "destructive",
      });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: async (predictionId: string) => {
      const response = await apiRequest("POST", `/api/staff/goal-predictions/${predictionId}/reject`, {
        reviewerId: staffUser?.id,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Prediction rejected",
        description: "The goal prediction has been rejected.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/staff/goal-predictions/pending"] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to reject",
        description: error.message || "Something went wrong",
        variant: "destructive",
      });
    },
  });

  const handleCreateGame = () => {
    if (!gameForm.homeTeam || !gameForm.awayTeam || !gameForm.venue || !gameForm.gameDate) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    createGameMutation.mutate({
      ...gameForm,
      gameDate: new Date(gameForm.gameDate).toISOString(),
      homeOdds: parseFloat(gameForm.homeOdds),
      awayOdds: parseFloat(gameForm.awayOdds),
      drawOdds: parseFloat(gameForm.drawOdds),
    });
  };

  if (!staffUser?.isStaff) {
    return null;
  }

  return (
    <div className="min-h-screen bg-shhc-bg p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <h1 className="text-2xl font-bold text-white">
              <i className="fas fa-shield-alt text-shhc-yellow mr-2"></i>
              SHHCPL Staff Panel
            </h1>
            <Badge variant="secondary" className="bg-shhc-yellow text-black">
              {pendingPredictions.length} Pending
            </Badge>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-gray-400">Welcome, {staffUser.username}</span>
            {onLogout && (
              <Button
                onClick={onLogout}
                variant="outline"
                className="border-gray-600 text-gray-400 hover:text-white"
              >
                Logout
              </Button>
            )}
          </div>
        </div>
        
        <Tabs defaultValue="predictions" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="predictions">
              Goal Predictions {pendingPredictions.length > 0 && (
                <Badge className="ml-2 bg-shhc-yellow text-black">{pendingPredictions.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="games">
              <GamepadIcon className="h-4 w-4 mr-2" />
              Manage Games
            </TabsTrigger>
          </TabsList>

          <TabsContent value="predictions" className="space-y-3 mt-6">
            {pendingPredictions.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                <Clock className="mx-auto h-8 w-8 mb-3 opacity-50" />
                <p>No pending predictions</p>
                <p className="text-sm">All caught up!</p>
              </div>
            ) : (
              pendingPredictions.map((prediction) => (
                <div key={prediction.id} className="bg-gray-700 rounded-lg p-4 border-l-4 border-shhc-yellow">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <div className="font-medium text-white">
                        {prediction.user.username}
                      </div>
                      <div className="text-sm text-gray-400">
                        {formatDistanceToNow(prediction.placedAt)} ago
                      </div>
                    </div>
                    <Badge variant="outline" className="border-shhc-yellow text-shhc-yellow">
                      Pending Review
                    </Badge>
                  </div>
                  
                  <div className="mb-3">
                    <div className="text-sm text-gray-300 mb-1">
                      <strong>Game:</strong> {prediction.game.homeTeam} vs {prediction.game.awayTeam}
                    </div>
                    <div className="text-sm text-gray-300 mb-1">
                      <strong>Player:</strong> {prediction.playerName} 
                      <span className="ml-2 text-xs bg-gray-600 px-2 py-1 rounded">
                        {prediction.team === 'home' ? prediction.game.homeTeam : prediction.game.awayTeam}
                      </span>
                    </div>
                    <div className="text-sm text-gray-300">
                      <strong>Predicted Goals:</strong> {prediction.predictedGoals}
                    </div>
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      className="bg-shhc-green hover:bg-shhc-green/80 flex-1"
                      onClick={() => approveMutation.mutate(prediction.id)}
                      disabled={approveMutation.isPending || rejectMutation.isPending}
                    >
                      <Check className="h-4 w-4 mr-1" />
                      Approve
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      className="bg-shhc-red hover:bg-shhc-red/80 flex-1"
                      onClick={() => rejectMutation.mutate(prediction.id)}
                      disabled={approveMutation.isPending || rejectMutation.isPending}
                    >
                      <X className="h-4 w-4 mr-1" />
                      Reject
                    </Button>
                  </div>
                </div>
              ))
            )}
          </TabsContent>

          <TabsContent value="games" className="space-y-6 mt-6">
            <Card className="bg-gray-700 border-gray-600">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Plus className="h-5 w-5 mr-2" />
                  Add New Game
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Home Team</label>
                    <Input
                      placeholder="Home team name"
                      value={gameForm.homeTeam}
                      onChange={(e) => setGameForm({ ...gameForm, homeTeam: e.target.value })}
                      className="bg-gray-600 border-gray-500"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Away Team</label>
                    <Input
                      placeholder="Away team name"
                      value={gameForm.awayTeam}
                      onChange={(e) => setGameForm({ ...gameForm, awayTeam: e.target.value })}
                      className="bg-gray-600 border-gray-500"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Venue</label>
                    <Input
                      placeholder="Game venue"
                      value={gameForm.venue}
                      onChange={(e) => setGameForm({ ...gameForm, venue: e.target.value })}
                      className="bg-gray-600 border-gray-500"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Game Date & Time</label>
                    <Input
                      type="datetime-local"
                      value={gameForm.gameDate}
                      onChange={(e) => setGameForm({ ...gameForm, gameDate: e.target.value })}
                      className="bg-gray-600 border-gray-500"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Home Odds</label>
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="2.50"
                      value={gameForm.homeOdds}
                      onChange={(e) => setGameForm({ ...gameForm, homeOdds: e.target.value })}
                      className="bg-gray-600 border-gray-500"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Away Odds</label>
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="2.50"
                      value={gameForm.awayOdds}
                      onChange={(e) => setGameForm({ ...gameForm, awayOdds: e.target.value })}
                      className="bg-gray-600 border-gray-500"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Draw Odds</label>
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="3.20"
                      value={gameForm.drawOdds}
                      onChange={(e) => setGameForm({ ...gameForm, drawOdds: e.target.value })}
                      className="bg-gray-600 border-gray-500"
                    />
                  </div>
                </div>
                
                <Button
                  onClick={handleCreateGame}
                  disabled={createGameMutation.isPending}
                  className="w-full bg-shhc-blue hover:bg-shhc-blue/80"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Create Game
                </Button>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-700 border-gray-600">
              <CardHeader>
                <CardTitle className="text-white">Existing Games ({games.length})</CardTitle>
              </CardHeader>
              <CardContent>
                {games.length === 0 ? (
                  <p className="text-gray-400 text-center py-4">No games scheduled</p>
                ) : (
                  <div className="space-y-2">
                    {games.map((game) => (
                      <div key={game.id} className="bg-gray-600 p-3 rounded border-l-4 border-shhc-blue">
                        <div className="flex justify-between items-center">
                          <div>
                            <div className="text-white font-medium">
                              {game.homeTeam} vs {game.awayTeam}
                            </div>
                            <div className="text-sm text-gray-400">
                              {game.venue} • {new Date(game.gameDate).toLocaleString()}
                            </div>
                          </div>
                          <Badge variant="outline" className="border-gray-500 text-gray-300">
                            {game.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}