import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/sidebar";
import GameCard from "@/components/game-card";
import BettingSlip from "@/components/betting-slip";
import Leaderboard from "@/components/leaderboard";
import RecentActivity from "@/components/recent-activity";
import GoalPredictionCard from "@/components/goal-prediction-card";
import StaffPanel from "@/components/staff-panel";
import UserPredictions from "@/components/user-predictions";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Filter, Plus } from "lucide-react";
import { Game, User } from "@shared/schema";
import { useState } from "react";

export default function Dashboard() {
  const [selectedBets, setSelectedBets] = useState<Array<{
    gameId: string;
    betType: string;
    odds: string;
    gameTitle: string;
  }>>([]);

  const { data: user } = useQuery<User>({
    queryKey: ["/api/user"],
  });

  const { data: games = [] } = useQuery<Game[]>({
    queryKey: ["/api/games"],
  });

  const handleAddBet = (gameId: string, betType: string, odds: string, gameTitle: string) => {
    const existingBet = selectedBets.find(bet => bet.gameId === gameId);
    if (existingBet) {
      // Update existing bet
      setSelectedBets(bets => 
        bets.map(bet => 
          bet.gameId === gameId 
            ? { gameId, betType, odds, gameTitle }
            : bet
        )
      );
    } else {
      // Add new bet
      setSelectedBets(bets => [...bets, { gameId, betType, odds, gameTitle }]);
    }
  };

  const handleRemoveBet = (gameId: string) => {
    setSelectedBets(bets => bets.filter(bet => bet.gameId !== gameId));
  };

  const clearBetSlip = () => {
    setSelectedBets([]);
  };

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-shhc-primary text-white">
      {/* Sidebar Navigation */}
      <Sidebar user={user} />

      {/* Main Content */}
      <main className="flex-1 lg:flex">
        {/* Main Content */}
        <div className="flex-1 p-6">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold mb-2">SHHC Betting Platform</h2>
              <p className="text-gray-400">Place bets and predict player goals</p>
            </div>
            <div className="flex items-center space-x-4 mt-4 sm:mt-0">
              <Select defaultValue="all">
                <SelectTrigger className="w-[180px] bg-shhc-secondary border-gray-600">
                  <SelectValue placeholder="Filter games" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Games</SelectItem>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="week">This Week</SelectItem>
                </SelectContent>
              </Select>
              <Button className="bg-shhc-green hover:bg-shhc-green/80">
                <Filter className="mr-2 h-4 w-4" />
                Filter
              </Button>
            </div>
          </div>

          {/* Tabs for different betting modes */}
          <Tabs defaultValue="regular-betting" className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-shhc-secondary">
              <TabsTrigger value="regular-betting" className="data-[state=active]:bg-shhc-green">
                Regular Betting
              </TabsTrigger>
              <TabsTrigger value="goal-predictions" className="data-[state=active]:bg-shhc-blue">
                Goal Predictions
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="regular-betting" className="mt-6">
              <div className="space-y-4">
                {games.length > 0 ? (
                  <>
                    {games.map((game) => (
                      <GameCard 
                        key={game.id} 
                        game={game} 
                        onAddBet={handleAddBet}
                        selectedBet={selectedBets.find(bet => bet.gameId === game.id)}
                      />
                    ))}

                    {/* Load More Button */}
                    <div className="text-center pt-6">
                      <Button variant="outline" className="bg-gray-700 hover:bg-gray-600 border-gray-600">
                        <Plus className="mr-2 h-4 w-4" />
                        Load More Games
                      </Button>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-12 text-gray-400">
                    <div className="w-16 h-16 bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className="fas fa-hockey-puck text-2xl"></i>
                    </div>
                    <h3 className="text-lg font-medium mb-2">No Games Available</h3>
                    <p className="text-sm">No hockey games are currently scheduled for betting.</p>
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="goal-predictions" className="mt-6">
              <div className="space-y-4">
                {games.length > 0 ? (
                  games.map((game) => (
                    <GoalPredictionCard 
                      key={game.id} 
                      game={game} 
                      user={user}
                    />
                  ))
                ) : (
                  <div className="text-center py-12 text-gray-400">
                    <div className="w-16 h-16 bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className="fas fa-target text-2xl"></i>
                    </div>
                    <h3 className="text-lg font-medium mb-2">No Games for Predictions</h3>
                    <p className="text-sm">No hockey games are available for goal predictions.</p>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Right Sidebar */}
        <aside className="lg:w-80 bg-shhc-secondary border-l border-gray-700 p-6">
          <BettingSlip 
            selectedBets={selectedBets}
            onRemoveBet={handleRemoveBet}
            onClearAll={clearBetSlip}
            user={user}
          />
          {/* Staff panel removed from dashboard - now has dedicated /staff page */}
          <UserPredictions user={user} />
          <Leaderboard />
          <RecentActivity />
        </aside>
      </main>

      {/* Mobile Navigation */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-shhc-secondary border-t border-gray-700 px-4 py-2">
        <div className="flex items-center justify-around">
          <button className="flex flex-col items-center space-y-1 p-2 text-shhc-green">
            <i className="fas fa-home text-lg"></i>
            <span className="text-xs">Home</span>
          </button>
          <button className="flex flex-col items-center space-y-1 p-2 text-gray-400">
            <i className="fas fa-hockey-puck text-lg"></i>
            <span className="text-xs">Games</span>
          </button>
          <button className="flex flex-col items-center space-y-1 p-2 text-gray-400">
            <i className="fas fa-receipt text-lg"></i>
            <span className="text-xs">Bets</span>
          </button>
          <button className="flex flex-col items-center space-y-1 p-2 text-gray-400">
            <i className="fas fa-trophy text-lg"></i>
            <span className="text-xs">Rankings</span>
          </button>
          <button className="flex flex-col items-center space-y-1 p-2 text-gray-400">
            <i className="fas fa-user text-lg"></i>
            <span className="text-xs">Profile</span>
          </button>
        </div>
      </nav>
    </div>
  );
}
