import { useState } from "react";
import StaffLogin from "@/components/staff-login";
import StaffPanel from "@/components/staff-panel";

export default function StaffPage() {
  const [staffUser, setStaffUser] = useState(null);

  const handleLogin = (staff: any) => {
    setStaffUser(staff);
  };

  const handleLogout = () => {
    setStaffUser(null);
  };

  if (!staffUser) {
    return <StaffLogin onLogin={handleLogin} />;
  }

  return <StaffPanel staffUser={staffUser} onLogout={handleLogout} />;
}